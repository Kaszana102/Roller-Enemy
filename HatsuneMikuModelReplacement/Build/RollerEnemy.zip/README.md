# Roller Enemy v1.0.3
New spiky enemy, which rolls towards targets!

## Overview
Mod which adds new Enemy. It's a spiky creature which likes to hide in its shell. 
From time to time, it will search for any nearby dangers using its big eye. If endangered
it will show its spikes, and roll towards threats!

## Changelog
	- v1.0.3
		- Fixed scanning
	- v1.0.1
		- Fixed map dot (sometimes it was seen by player in dungeon)
	- v1.0.0
		- Release